library(testthat)
library(shift8)

test_check("shift8")
