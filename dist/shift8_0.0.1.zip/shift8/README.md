# shift8

shift8 is a satirical R package that mocks p-hacking by "installing stars" in regression
outputs while keeping internal table consistency. It is intended for humor and to encourage
better research practices, not for real inference.

WARNING: FOR ENTERTAINMENT PURPOSES ONLY. Do not use for real analysis.

## What it does (satire)

- table_only mode: adjusts estimates just enough to reach a chosen alpha, then recomputes
  statistics and confidence intervals.
- lm_synthetic_y mode: for lm objects only, builds a synthetic response that preserves
  residuals while nudging coefficients over significance thresholds.

Default behavior:
- If the input is an lm object, shift8 returns a shifted lm (mode = "auto").
- Otherwise, it returns a shift8_table (mode = "auto").

## Example (satirical)

```r
fit <- lm(mpg ~ wt + hp, data = mtcars)
shifted <- shift8(fit, mode = "lm_synthetic_y", scope = "non_intercept")
shifted_table <- shift8(fit, mode = "table_only")
```
